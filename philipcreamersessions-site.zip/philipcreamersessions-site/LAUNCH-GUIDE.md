# Launching philipcreamersessions.com

This folder is the whole website. `index.html` is the page. `assets/` holds the photo and the three vocal reels.

## 1. Put the site online (Netlify, free)

1. Create a free account at netlify.com.
2. Go to **Add new project → Deploy manually**.
3. Drag the whole `philipcreamersessions-site` folder onto the upload area.
4. Netlify gives you a temporary address like `something-123.netlify.app`. Open it to check the site.
5. Optional: under **Project configuration → Change project name**, rename it to `philipcreamersessions`. The temporary address then becomes `philipcreamersessions.netlify.app`.

## 2. Connect your domain

**In Netlify:** go to **Domain management → Add a domain → Add a domain you already own**. Enter `philipcreamersessions.com`, then choose to keep your current DNS provider (external DNS).

**In Squarespace Domains** (your Google-bought domain is now managed here): log in at account.squarespace.com/domains. Open `philipcreamersessions.com`, then open **DNS → DNS Settings**.

1. **Remove** any existing records for the website:
   - A or AAAA records with host `@`
   - a CNAME record with host `www`
   - Squarespace's default "parking" records, if present
2. **Add** these two records:

   | Type  | Host | Data                                     |
   |-------|------|------------------------------------------|
   | A     | @    | 75.2.60.5                                |
   | CNAME | www  | *your-project-name*.netlify.app          |

3. **Don't touch** MX or TXT records. Those run your email (Philip@philipcreamersessions.com). Deleting them would break your email.

Changes can take from a few minutes up to a day to take effect. Netlify then adds the secure padlock (HTTPS) automatically.

## 3. Turn on Calendly booking

1. In Calendly (Standard plan), create the four booking types:
   - Master track lead vocal
   - Master track background vocals
   - Songwriting demo vocals
   - Studio day
2. Copy each booking type's link (**Copy link**).
3. Open `index.html` in any text editor and find the block near the bottom marked `CALENDLY LINKS`. Paste each link between the quotes:

   ```
   var CALENDLY = {
     lead: "https://calendly.com/…/master-track-lead-vocal",
     bgv:  "https://calendly.com/…/background-vocals",
     demo: "https://calendly.com/…/songwriting-demo-vocals",
     day:  "https://calendly.com/…/studio-day"
   };
   ```

4. Save, then go to **Deploys** in Netlify and drag the folder in again.

Each service tab on the page then shows its Calendly calendar, styled to match the site. Any service without a link keeps using the email request form, which opens the visitor's email app with their request filled in and addressed to you.

## Making changes later

Edit the files, or ask Claude to. Then drag the folder onto Netlify's **Deploys** page again. The new version replaces the old one within seconds.
